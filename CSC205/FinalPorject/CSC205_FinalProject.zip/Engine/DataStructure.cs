﻿using System;
using System.Collections.Generic;
using System.Diagnostics.SymbolStore;
using System.Text;

namespace Engine
{
    public class DataStructure
    {
        public string AccessTime { get; set; }
        public string SearchTime { get; set; }
        public string InsertTime { get; set; }
        public string DeleteTime { get; set; }
        public string SpaceComplexity { get; set; }

        public string Advantages(string str1)
        {
            return str1;
        }

        public string Disadvantages(string str2)
        {
            return str2;
        }
    }
}
