﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Engine
{
    public class Graph1 : DataStructure
    {
        public Graph1()
        {
            this.AccessTime = "Access Time: N/A";
            this.SearchTime = "Search Time: N/A";
            this.InsertTime = "Insert Time: N/A";
            this.DeleteTime = "Delete Time: N/A";
            this.SpaceComplexity = "Space: N/A";
        }
    }
}
