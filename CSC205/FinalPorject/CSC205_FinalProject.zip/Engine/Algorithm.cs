﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Engine
{
    public class Algorithm
    {
        public string TimeComplexity { get; set; }
        public string SpaceComplexity { get; set; }

        public string Advantages(string str1)
        {

            return str1;
        }

        public string Disadvantages(string str2)
        {
            return str2;
        }
    }
}
